const Hapi = require('@hapi/hapi');
const { nanoid } = require('nanoid');

const books = [];

const init = async () => {
    const server = Hapi.server({
        port: 9000,
        host: 'localhost',
    });

    // Endpoint untuk menambahkan buku
    server.route({
        method: 'POST',
        path: '/books',
        handler: (request, h) => {
            const { name, year, author, summary, publisher, pageCount, readPage } = request.payload;

            // Validasi input
            if (!name) {
                return h.response({
                    status: 'fail',
                    message: 'Gagal menambahkan buku. Mohon isi nama buku',
                }).code(400);
            }
            if (readPage > pageCount) {
                return h.response({
                    status: 'fail',
                    message: 'Gagal menambahkan buku. readPage tidak boleh lebih besar dari pageCount',
                }).code(400);
            }

            // Logika untuk menambahkan buku
            const bookId = nanoid();
            const newBook = {
                id: bookId,
                name,
                year,
                author,
                summary,
                publisher,
                pageCount,
                readPage,
                finished: readPage === pageCount,
                insertedAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
            };
            books.push(newBook);

            return h.response({
                status: 'success',
                message: 'Buku berhasil ditambahkan',
                data: {
                    bookId: bookId,
                },
            }).code(201);
        },
    });

    // Endpoint untuk mendapatkan semua buku
    server.route({
        method: 'GET',
        path: '/books',
        handler: (request, h) => {
            const response = {
                status: 'success',
                data: {
                    books: books.map(({ id, name, publisher }) => ({ id, name, publisher })),
                },
            };
            return h.response(response).code(200);
        },
    });

    // Endpoint untuk mendapatkan detail buku dengan ID
    server.route({
        method: 'GET',
        path: '/books/{id}',
        handler: (request, h) => {
            const { id } = request.params;
            const book = books.find(b => b.id === id);

            if (!book) {
                return h.response({
                    status: 'fail',
                    message: 'Buku tidak ditemukan',
                }).code(404);
            }

            return h.response({
                status: 'success',
                data: {
                    book: {
                        id: book.id,
                        name: book.name,
                        publisher: book.publisher,
                        year: book.year,
                        author: book.author,
                        summary: book.summary,
                        pageCount: book.pageCount,
                        readPage: book.readPage,
                        finished: book.finished,
                        reading: book.reading || false, // Tambahkan 'reading' jika tidak ada
                    },
                },
            }).code(200);
        },
    });

    // Endpoint untuk memperbarui buku dengan ID
    server.route({
        method: 'PUT',
        path: '/books/{id}',
        handler: (request, h) => {
            const { id } = request.params;
            const { name, year, author, summary, publisher, pageCount, readPage } = request.payload;

            const index = books.findIndex(b => b.id === id);

            // Validasi jika buku tidak ditemukan
            if (index === -1) {
                return h.response({
                    status: 'fail',
                    message: 'Buku tidak ditemukan',
                }).code(404);
            }

            // Validasi input
            if (!name) {
                return h.response({
                    status: 'fail',
                    message: 'Gagal memperbarui buku. Mohon isi nama buku',
                }).code(400);
            }
            if (readPage > pageCount) {
                return h.response({
                    status: 'fail',
                    message: 'Gagal memperbarui buku. readPage tidak boleh lebih besar dari pageCount',
                }).code(400);
            }

            // Update buku
            const updatedBook = {
                ...books[index],
                name,
                year,
                author,
                summary,
                publisher,
                pageCount,
                readPage,
                finished: readPage === pageCount,
                updatedAt: new Date().toISOString(),
            };

            books[index] = updatedBook;

            return h.response({
                status: 'success',
                message: 'Buku berhasil diperbarui',
                data: {
                    book: updatedBook, // Kembalikan objek buku yang diperbarui
                },
            }).code(200);
        },
    });

    // Endpoint untuk menghapus buku dengan ID
    server.route({
        method: 'DELETE',
        path: '/books/{id}',
        handler: (request, h) => {
            const { id } = request.params;
            const index = books.findIndex(b => b.id === id);

            // Validasi jika buku tidak ditemukan
            if (index === -1) {
                return h.response({
                    status: 'fail',
                    message: 'Buku gagal dihapus. Id tidak ditemukan',
                }).code(404);
            }

            books.splice(index, 1);

            return h.response({
                status: 'success',
                message: 'Buku berhasil dihapus',
            }).code(200);
        },
    });

    await server.start();
    console.log(`Server berjalan di ${server.info.uri}`);
};

process.on('unhandledRejection', (err) => {
    console.log(err);
    process.exit(1);
});

init();
